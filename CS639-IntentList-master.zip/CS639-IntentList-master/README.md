CS639-IntentList
================
contain intents such as SMS, Phone, Browser, Maps & Share
